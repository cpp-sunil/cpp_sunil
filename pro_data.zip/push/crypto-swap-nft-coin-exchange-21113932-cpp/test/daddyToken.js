const { expect } = require("chai");
const { ethers } = require("hardhat");

// const { BN, time, expectEvent, expectRevert } = require('@openzeppelin/test-helpers')
// await time.increase(60 * 60 * 24 * 7 + 1);
// await time.advanceBlock();
// time.latest()
// time.latestBlock()
const zeroAddress = "0x0000000000000000000000000000000000000000"
["0xA93647C91133454fB265821334083375b12F06e5","0x12E700EceBD1af4217540Ab6CC1655AD39cC2123","0x4B20993Bc481177ec7E8f571ceCaE8A9e22C02db","0x78731D3Ca6b7E34aC0F824c42a7cC18A495cabaB","0x617F2E2fD72FD9D5503197092aC168c91465E7f2"]

describe("DaddyToken", function () {
  let tx, balance, userInfo, userVestingInfo;
  let DaddyToken;
  let daddyToken;

  before(async () => {

    [owner, alice, bob, cindy, domino, erik, fred, george, julias, mike] = await ethers.getSigners();

    // Deploy DaddyToken
    DaddyToken = await ethers.getContractFactory("HopperSwapToken");
    daddyToken = await DaddyToken.connect(owner).deploy(parseUnits(10000));
    await daddyToken.deployed();

    console.log('DaddyToken contract deployed at', daddyToken.address);

  });
  
  it("Cannot mint more than Supply", async function () {
    tx = await daddyToken.connect(owner).mint(owner.address, parseUnits(5000));
    await tx.wait()

    balance = await daddyToken.balanceOf(owner.address)
    console.log("owner balance", formatUnits(balance));

    tx = await daddyToken.connect(owner).transferOwnership(alice.address);
    await tx.wait()

    tx = await daddyToken.connect(alice).mint(alice.address, parseUnits(5000));
    await tx.wait()

    tx = await daddyToken.connect(alice).mint(alice.address, parseUnits(5000));
    await tx.wait()

  });




});


// Lsit of Helper functions
// Converts checksum
const address = (params) => {
  return ethers.utils.getAddress(params);
}

// Converts token units to smallest individual token unit, eg: 1 DAI = 10^18 units 
const parseUnits = (params) => {
  return ethers.utils.parseUnits(params.toString(), 18);
}

// Converts token units from smallest individual unit to token unit, opposite of parseUnits
const formatUnits = (params) => {
  return ethers.utils.formatUnits(params.toString(), 18);
}

const increaseTime = async (amount, type) => {
  if (type == 'seconds') {
    await time.increase(amount);
  } else if (type == 'minutes') {
    await time.increase(60 * amount);
  } else if (type == 'hours') {
    await time.increase(60 * 60 * amount);
  } else if (type == 'days') {
    await time.increase(60 * 60 * 24 * amount);
  } else if (type == 'weeks') {
    await time.increase(60 * 60 * 24 * 7 * amount);
  } else if (type == 'months') {
    await time.increase(60 * 60 * 24 * 30 * amount);
  } else if (type == 'years') {
    await time.increase(60 * 60 * 24 * 30 * 12 * amount);
    // await time.increase(60 * 60 * 24 * 7 + 1);
  }
}

const parseUserInfo = (params) => {
    return {
        wallet: params.wallet,
        allocatedAmount: formatUnits(params.allocatedAmount),
        claimedAmount: formatUnits(params.claimedAmount),
    }
}

const parseVestingInfo = (params) => {
  return {
      date: params.date.toString(),
      tokensUnlockedPercentage: params.tokensUnlockedPercentage.toString()
  }
}
