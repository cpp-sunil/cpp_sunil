const Web3 = require('web3');
const web3 = new Web3(new Web3.providers.HttpProvider("https://eth-ropsten.alchemyapi.io/v2/N2XCjoURDrc_zvFotTcERGOjExUwGRuu"));
const nftABI = require("./nftABI.json");
const marketplaceABI = require("./marketplaceABI.json");

const nftAddress = '0x7994B66D88F618bAD5930946Bff775c4230046e2';
const marketplaceAddress = '0x6391443646975fE331632bB191824a58f570d5E0';
const nftData = new web3.eth.Contract(nftABI,nftAddress);
const marketplaceData = new web3.eth.Contract(marketplaceABI,marketplaceAddress);


async function allGetFunctions() {
	try {
		var name = await nftData.methods.name().call();
		console.log("Name ==> ",name);
		var symbol = await nftData.methods.symbol().call();
		console.log("Symbol ==> ", symbol)
		var owner = await marketplaceData.methods.owner().call();
		console.log("owner Address ==> ", owner);
		var maxCutPerMillion = await marketplaceData.methods.maxCutPerMillion().call();
		console.log("maxCutPerMillion ==> ", maxCutPerMillion);
		var orderByAssetId = await marketplaceData.methods.orderByAssetId("0x7994B66D88F618bAD5930946Bff775c4230046e2","3").call();
		console.log("orderByAssetId ==> ",orderByAssetId);
		var bidByOrderId = await marketplaceData.methods.bidByOrderId("0x7994B66D88F618bAD5930946Bff775c4230046e2","3").call();
		console.log("bidByOrderId ==> ",bidByOrderId);
		

	}
	catch (error) {
		console.log("error===>", error);
	}
}

async function mint() {
	try {
		let Data = await nftData.methods.mint("3").encodeABI()
		const txObject = {
			to: nftAddress,
			gasPrice: web3.utils.toHex('17000000640'),
			gasLimit: web3.utils.toHex('3000000'),
			data: Data
		};
		const signPromise = await web3.eth.accounts.signTransaction(txObject,"9767124ee416c1b5df3c541b8935ba0e1afa5d0a708effd4df9059f1209685d4");
		let receipt = await web3.eth.sendSignedTransaction(signPromise.raw || signPromise.rawTransaction)
		if (receipt) {
			console.log("Mint=======>", receipt);
		}


	}
	catch (error) {
		console.log("Error===>", error);

	}
}
async function approve() {
	try {
		let Data = await nftData.methods.approve("0x6391443646975fE331632bB191824a58f570d5E0", "3").encodeABI()
		const txObject = {
			to: nftAddress,
			gasPrice: web3.utils.toHex('17000000640'),
			gasLimit: web3.utils.toHex('5000000'),
			data: Data
		};
		const signPromise = await web3.eth.accounts.signTransaction(txObject,"9767124ee416c1b5df3c541b8935ba0e1afa5d0a708effd4df9059f1209685d4");
		let receipt = await web3.eth.sendSignedTransaction(signPromise.raw || signPromise.rawTransaction)
		if (receipt) {
			console.log("Approve=======>", receipt);
		}


	}
	catch (error) {
		console.log("Error===>", error);

	}
}
async function createOrder() {
	try {
		let Data = await marketplaceData.methods.createOrder("0x7994B66D88F618bAD5930946Bff775c4230046e2", "3", "10000000000000", "1648958813").encodeABI()
		const txObject = {
			to: marketplaceAddress,
			gasPrice: web3.utils.toHex('17000000640'),
			gasLimit: web3.utils.toHex('3000000'),
			data: Data
		};
		const signPromise = await web3.eth.accounts.signTransaction(txObject, "9767124ee416c1b5df3c541b8935ba0e1afa5d0a708effd4df9059f1209685d4");
		let receipt = await web3.eth.sendSignedTransaction(signPromise.raw || signPromise.rawTransaction)
		if (receipt) {
			console.log("createOrder=======>", receipt);
		}


	}
	catch (error) {
		console.log("Error===>", error);

	}
}
async function updateOrder() {
	try {
		let Data = await marketplaceData.methods.updateOrder("0x7994B66D88F618bAD5930946Bff775c4230046e2", "3", "10000000000001", "1648958813").encodeABI()
		const txObject = {
			to: marketplaceAddress,
			gasPrice: web3.utils.toHex('17000000640'),
			gasLimit: web3.utils.toHex('3000000'),
			data: Data
		};
		const signPromise = await web3.eth.accounts.signTransaction(txObject, "9767124ee416c1b5df3c541b8935ba0e1afa5d0a708effd4df9059f1209685d4");
		let receipt = await web3.eth.sendSignedTransaction(signPromise.raw || signPromise.rawTransaction)
		if (receipt) {
			console.log("updateOrder=======>", receipt);
		}


	}
	catch (error) {
		console.log("Error===>", error);

	}
}
async function safeExecuteOrder() {
	try {
		let Data = await marketplaceData.methods.safeExecuteOrder("0x7994B66D88F618bAD5930946Bff775c4230046e2","1").encodeABI()
		const txObject = {
			to: marketplaceAddress,
			gasPrice: web3.utils.toHex('17000000640'),
			gasLimit: web3.utils.toHex('3000000'),
			value:"10000000000000",
			data: Data
		};
		const signPromise = await web3.eth.accounts.signTransaction(txObject, "796ec1292a19dce4f0d8e921efb15e07861c05882552d86121670d0d75d55965");
		let receipt = await web3.eth.sendSignedTransaction(signPromise.raw || signPromise.rawTransaction)
		if (receipt) {
			console.log("safeExecuteOrder=======>", receipt);
		}


	}
	catch (error) {
		console.log("Error===>", error);

	}
}
async function safePlaceBid() {
	try {
		let Data = await marketplaceData.methods.safePlaceBid("0x7994B66D88F618bAD5930946Bff775c4230046e2","3","1648958813").encodeABI()
		const txObject = {
			to: marketplaceAddress,
			gasPrice: web3.utils.toHex('17000000640'),
			gasLimit: web3.utils.toHex('3000000'),
			value:"10000000000005",
			data: Data
		};
		const signPromise = await web3.eth.accounts.signTransaction(txObject, "796ec1292a19dce4f0d8e921efb15e07861c05882552d86121670d0d75d55965");
		let receipt = await web3.eth.sendSignedTransaction(signPromise.raw || signPromise.rawTransaction)
		if (receipt) {
			console.log("safePlaceBid=======>", receipt);
		}


	}
	catch (error) {
		console.log("Error===>", error);

	}
}
async function acceptBid() {
	try {
		let Data = await marketplaceData.methods.acceptBid("0x7994B66D88F618bAD5930946Bff775c4230046e2","2","10000000000001").encodeABI()
		const txObject = {
			to: marketplaceAddress,
			gasPrice: web3.utils.toHex('17000000640'),
			gasLimit: web3.utils.toHex('3000000'),
			data: Data
		};
		const signPromise = await web3.eth.accounts.signTransaction(txObject, "9767124ee416c1b5df3c541b8935ba0e1afa5d0a708effd4df9059f1209685d4");
		let receipt = await web3.eth.sendSignedTransaction(signPromise.raw || signPromise.rawTransaction)
		if (receipt) {
			console.log("acceptBid=======>", receipt);
		}


	}
	catch (error) {
		console.log("Error===>", error);

	}
}
async function cancelBid() {
	try {
		let Data = await marketplaceData.methods.cancelBid("0x7994B66D88F618bAD5930946Bff775c4230046e2","3").encodeABI()
		const txObject = {
			to: marketplaceAddress,
			gasPrice: web3.utils.toHex('17000000640'),
			gasLimit: web3.utils.toHex('3000000'),
			data: Data
		};
		const signPromise = await web3.eth.accounts.signTransaction(txObject, "796ec1292a19dce4f0d8e921efb15e07861c05882552d86121670d0d75d55965");
		let receipt = await web3.eth.sendSignedTransaction(signPromise.raw || signPromise.rawTransaction)
		if (receipt) {
			console.log("cancelBid=======>", receipt);
		}


	}
	catch (error) {
		console.log("Error===>", error);

	}
}
async function cancelOrder() {
	try {
		let Data = await marketplaceData.methods.cancelOrder("0x7994B66D88F618bAD5930946Bff775c4230046e2","3").encodeABI()
		const txObject = {
			to: marketplaceAddress,
			gasPrice: web3.utils.toHex('17000000640'),
			gasLimit: web3.utils.toHex('3000000'),
			data: Data
		};
		const signPromise = await web3.eth.accounts.signTransaction(txObject, "9767124ee416c1b5df3c541b8935ba0e1afa5d0a708effd4df9059f1209685d4");
		let receipt = await web3.eth.sendSignedTransaction(signPromise.raw || signPromise.rawTransaction)
		if (receipt) {
			console.log("cancelOrder=======>", receipt);
		}


	}
	catch (error) {
		console.log("Error===>", error);

	}
}
allGetFunctions();
// mint();
// approve();
// createOrder();
// updateOrder();
// safeExecuteOrder();
// safePlaceBid();
// acceptBid();
// cancelBid();
// cancelOrder();








