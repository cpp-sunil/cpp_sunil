var Web3 = require('web3');
var web3 = new Web3();
var message = "I authorize the creation of an Identity on my behalf.";
 const timestamp = Math.round(new Date() / 1000) - 1
console.log("version :", web3.version);
const hashedMessage = Web3.utils.sha3(message);
    console.log({ hashedMessage });
var signature = web3.eth.accounts.sign(hashedMessage, '450682b446cb06c9b68be95c834e6fd7d2cb71324f3fc3054053e407a39f8fab');

console.log("signature :", signature,timestamp);

var messageHash= web3.eth.accounts.hashMessage(Web3.utils.sha3(message));
// recover 1
var recover_1 = web3.eth.accounts.recover({
    messageHash: messageHash,
    v: signature.v,
    r: signature.r,
    s: signature.s
});
