const Web3 = require('web3');
const web3 = new Web3(new Web3.providers.HttpProvider("https://eth-ropsten.alchemyapi.io/v2/N2XCjoURDrc_zvFotTcERGOjExUwGRuu"));

const abi = [
  {
    "inputs": [
      {
        "internalType": "string[]",
        "name": "proposalNames",
        "type": "string[]"
      }
    ],
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "inputs": [],
    "name": "chairperson",
    "outputs": [
      {
        "internalType": "address",
        "name": "",
        "type": "address"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "to",
        "type": "address"
      }
    ],
    "name": "delegate",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "voter",
        "type": "address"
      }
    ],
    "name": "giveRightToVote",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "name": "proposals",
    "outputs": [
      {
        "internalType": "string",
        "name": "name",
        "type": "string"
      },
      {
        "internalType": "uint256",
        "name": "voteCount",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "proposal",
        "type": "uint256"
      }
    ],
    "name": "vote",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "",
        "type": "address"
      }
    ],
    "name": "voters",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "weight",
        "type": "uint256"
      },
      {
        "internalType": "bool",
        "name": "voted",
        "type": "bool"
      },
      {
        "internalType": "address",
        "name": "delegate",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "vote",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "winnerName",
    "outputs": [
      {
        "internalType": "string",
        "name": "winnerName_",
        "type": "string"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "winningProposal",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "winningProposal_",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  }
]
const contractAddress = '0xDc6031d976596900E26874229410c2758372aB2f';
const contractData = new web3.eth.Contract(abi, contractAddress);

allGetFunctions = async () => {
  try {
    var chairperson = await contractData.methods.chairperson().call();
    console.log("Chairperson Id ==> ", chairperson);
    var perposals = await contractData.methods.proposals("1").call();
    console.log("Perposal name ==> ", perposals);
    var winnerName = await contractData.methods.winnerName().call();
    console.log("winnerName ==> ", winnerName);

  }
  catch (error) {
    console.log("error===163", error)
  }
}

allGetFunctions();
async function giveRightToVote() {


  let Data = await contractData.methods.giveRightToVote("0x8FEdf399D3Aad3736ef4815a8cc992052c7bECb8").encodeABI()
  const txObject = {
    to: contractAddress,
    gasPrice: web3.utils.toHex('20000000000'),    // Always in Wei
    gasLimit: web3.utils.toHex('5000000'),
    data: Data
  };
  const signPromise = await web3.eth.accounts.signTransaction(txObject, "9767124ee416c1b5df3c541b8935ba0e1afa5d0a708effd4df9059f1209685d4");
  let receipt = await web3.eth.sendSignedTransaction(signPromise.raw || signPromise.rawTransaction)
  if (receipt) {
    console.log("giveRightToVote=======>", receipt);
  }

}
// giveRightToVote();

async function vote() {

  let Data = await contractData.methods.vote('1').encodeABI()
  const txObject = {
    to: contractAddress,
    gasPrice: web3.utils.toHex('20000000000'),    // Always in Wei
    gasLimit: web3.utils.toHex('5000000'),
    data: Data
  };
  const signPromise = await web3.eth.accounts.signTransaction(txObject, "796ec1292a19dce4f0d8e921efb15e07861c05882552d86121670d0d75d55965");
  let receipt = await web3.eth.sendSignedTransaction(signPromise.raw || signPromise.rawTransaction)

  console.log('Vote======>', receipt);

}
// vote();




