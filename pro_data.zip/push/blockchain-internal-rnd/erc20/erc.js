const Web3 = require('web3');
const web3 = new Web3(new Web3.providers.HttpProvider("https://eth-kovan.alchemyapi.io/v2/iEyMcCdlwtU7myvnunVLSoZWFo4ATVId"));
const ercABI = require("./erc20ABI.json");
const ercAddress = '0x8987F34c7B4FC2074172553F5c3AAD85d43E73e9';
const ercData = new web3.eth.Contract(ercABI,ercAddress);

async function approve() {
	try {
		let Data = await ercData.methods.approve("0xBDA1141bbb3986783Bdb0D622c13C4c44e161505", "10000000000").encodeABI()
		const txObject = {
			to: ercAddress,
			gasPrice: web3.utils.toHex('17000000640'),
			gasLimit: web3.utils.toHex('5000000'),
			data: Data
		};
		const signPromise = await web3.eth.accounts.signTransaction(txObject,"450682b446cb06c9b68be95c834e6fd7d2cb71324f3fc3054053e407a39f8fab");
		let receipt = await web3.eth.sendSignedTransaction(signPromise.raw || signPromise.rawTransaction)
		if (receipt) {
			console.log("Approve=======>", receipt);
		}


	}
	catch (error) {
		console.log("Error===>", error);

	}
}
async function transferFrom() {
	try {
		let Data = await ercData.methods.transferFrom("0x8c89E0F62864CA5d7e09688ACb20f0fd51cdC080", "0x032F7430F43eB680c1AF30E5E7fAA1619a8ed47b","10000000").encodeABI()
		const txObject = {
			to: ercAddress,
			gasPrice: web3.utils.toHex('17000000640'),
			gasLimit: web3.utils.toHex('5000000'),
			data: Data
		};
		const signPromise = await web3.eth.accounts.signTransaction(txObject,"8c86eba65d360f53b89ee6e3f4e36f3e07d0651c6302e85add6f8e7c05946000");
		let receipt = await web3.eth.sendSignedTransaction(signPromise.raw || signPromise.rawTransaction)
		if (receipt) {
			console.log("TransferFrom=======>", receipt);
		}


	}
	catch (error) {https://eth-kovan.alchemyapi.io/v2/iEyMcCdlwtU7myvnunVLSoZWFo4ATVId
		console.log("Error===>", error);

	}
}
// approve();
transferFrom();
