const router = require('express').Router();
const maticController= require('../controllers/matic');

/**
 * @swagger
 * /matic/generateMnemonic:
 *   get:
 *     tags:
 *       - MATIC COIN  
 *     description: Creating Docs
 *     produces:
 *       - application/json
 *     responses:
 *       200:
 *         description: Mnemonic key generated successfully
 *       404:
 *         description: Data not found
 *       500:
 *         description: Internal Server Error
 */
 router.get('/generateMnemonic',maticController.generateMnemonic);

 /**
 * @swagger
 * /matic/generateWallet:
 *   post:
 *     tags:
 *       - MATIC COIN  
 *     description: Creating Docs
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: mnemonic
 *         description: 
 *         in: formData
 *         required: true
 *       - name: count
 *         description: 
 *         in: formData
 *         required: true
 *       - name: accountName
 *         description: 
 *         in: formData
 *         required: false
 *     responses:
 *       200:
 *         description: Wallet generated successfully
 *       404:
 *         description: Data not found
 *       500:
 *         description: Internal Server Error
 */
  router.post('/generateWallet',maticController.generateWallet);

 /**
 * @swagger
 * /matic/getBalance:
 *   post:
 *     tags:
 *       - MATIC COIN  
 *     description: Creating Docs
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: address
 *         description: 
 *         in: formData
 *         required: true
 *     responses:
 *       200:
 *         description: Balance fetched successfully
 *       404:
 *         description: Data not found
 *       500:
 *         description: Internal Server Error
 */
  router.post('/getBalance',maticController.getBalance);


 /**
 * @swagger
 * /matic/withdraw:
 *   post:
 *     tags:
 *       - MATIC COIN  
 *     description: Creating Docs
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: senderAddress
 *         description: 
 *         in: formData
 *         required: true
 *       - name: privateKey
 *         description: 
 *         in: formData
 *         required: true
 *       - name: recieverAddress
 *         description: 
 *         in: formData
 *         required: true
 *       - name: amountToSend
 *         description: 
 *         in: formData
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *       404:
 *         description: Data not found
 *       500:
 *         description: Internal Server Error
 */
  router.post('/withdraw',maticController.withdraw);

 /**
 * @swagger
 * /matic/transfer:
 *   post:
 *     tags:
 *       - MATIC COIN  
 *     description: Creating Docs
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: fromAddress
 *         description: 
 *         in: formData
 *         required: true
 *       - name: fromPrivateKey
 *         description: 
 *         in: formData
 *         required: true
 *       - name: toAddress
 *         description: 
 *         in: formData
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *       404:
 *         description: Data not found
 *       500:
 *         description: Internal Server Error
 */
  router.post('/transfer',maticController.transfer);


//  /**
//  * @swagger
//  * /matic/send:
//  *   post:
//  *     tags:
//  *       - MATIC COIN  
//  *     description: Creating Docs
//  *     produces:
//  *       - application/json
//  *     parameters:
//  *       - name: serializedTransaction
//  *         description: 
//  *         in: formData
//  *         required: true
//  *     responses:
//  *       200:
//  *         description: Success
//  *       404:
//  *         description: Data not found
//  *       500:
//  *         description: Internal Server Error
//  */
//   router.post('/send',maticController.Send);


 

module.exports = router