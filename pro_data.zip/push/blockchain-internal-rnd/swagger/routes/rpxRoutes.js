const router = require('express').Router();
const rpxController= require('../controllers/rpx');

/**
 * @swagger
 * /matic/getBalance:
 *   post:
 *     tags:
 *       - RPX COIN  
 *     description: Creating Docs
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: address
 *         description: 
 *         in: formData
 *         required: true
 *     responses:
 *       200:
 *         description: Balance fetched successfully
 *       404:
 *         description: Data not found
 *       500:
 *         description: Internal Server Error
 */
 router.get('/getBalance',rpxController.getBalance);

 /**
 * @swagger
 * /matic/transfer:
 *   post:
 *     tags:
 *       - RPX COIN  
 *     description: Creating Docs
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: fromAddress
 *         description: 
 *         in: formData
 *         required: true
 *       - name: fromPrivateKey
 *         description: 
 *         in: formData
 *         required: true
 *       - name: toAddress
 *         description: 
 *         in: formData
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 *       404:
 *         description: Data not found
 *       500:
 *         description: Internal Server Error
 */
  router.post('/transfer',rpxController.transfer);

module.exports = router
