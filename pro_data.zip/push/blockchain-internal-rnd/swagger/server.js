const express=require("express");
const app = express();
const swaggerUi = require('swagger-ui-express');
const swaggerJSDoc = require("swagger-jsdoc");

const PORT=3000;

const swaggerDefinition = {
    info: {
        title: "Swagger Practice",
        version: "1.0.0",
        description: "Swagger API Docs",
    },
    host: "localhost:3000",
    basePath: "/",
};
const options = {
    swaggerDefinition: swaggerDefinition,
    apis: ["./routes/*.js"],
};
const swaggerSpec = swaggerJSDoc(options);
app.get("/swagger.json", (req, res) => {
    res.setHeader("Content-Type", "application/json");
    res.send(swaggerSpec);
});
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));
app.use("/matic",require("./routes/maticRoutes"));

app.listen(PORT,(error,result)=>{
    if(error){
        console.log("Server Listening error:,",error);
    }
    else{
        console.log("Server Listening on Port:",PORT);

    }
})
