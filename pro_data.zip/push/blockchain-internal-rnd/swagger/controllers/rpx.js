var erc = require('../config/rpx.json')



module.exports = {

    getBalance: async (address) => {
        try {
            const myContract = new erc.web3.eth.Contract(erc.contractABI, erc.contractAddress1);
            const balance = await myContract.methods.balanceOf(address).call();
            let balances = erc.web3.utils.fromWei(balance, 'ether')
            if (balances) {
                return balance;
            }
        } catch (error) {
            return error
        }
    },
    transfer: async (fromAddress, privateKey, toAddress, amount) => {
        try {
            var contract = new erc.web3.eth.Contract(erc.contractABI, erc.contractAddress1);
            const value1 = erc.web3.utils.fromWei(amount, 'ether');
            const Data = await contract.methods.transfer(toAddress, value1).encodeABI()
            const rawTransaction = {
                to: erc.contractAddress1,
                gasPrice: erc.web3.utils.toHex('30000000000'),    // Always in Wei (30 gwei)
                gasLimit: erc.web3.utils.toHex('200000'),      // Always in Wei
                data: Data  // Setting the pid 12 with 0 alloc and 0 deposit fee
            };
            const signPromise = await erc.web3.eth.accounts.signTransaction(rawTransaction, privateKey);
            const hash = await erc.web3.eth.sendSignedTransaction(signPromise.rawTransaction)

            if (hash) {
                var obj = {
                    hash: hash,
                    fromAddress: fromAddress,
                    date: new Date()
                }
                return obj;

            }
        } catch (error) {
            return error
        }

    }


    //******************************************ends of exports*****************************************/
}