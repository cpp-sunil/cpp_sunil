* 30/08/2021
    - Integration of user profile, Etherscan API on the front-end.