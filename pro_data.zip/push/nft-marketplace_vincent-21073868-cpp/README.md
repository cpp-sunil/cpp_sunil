* 04/09/2021
    - Integration of buy order, place bid, Etherscan API on the list orders of NF